features:
1. move & drag rectangles to any where you want.
2. click rectangles to change color.
3. option menu offer link to Coursera Android course web page.